"""Common constants."""
OUTPUT_DIR = 'out'
CHECKPOINT_DIR = 'checkpoints'
FIGURES_DIR = 'figures'
